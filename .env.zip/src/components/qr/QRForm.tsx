"use client";

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useDebounce } from 'use-debounce';
import { Save, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import QRCanvas from './QRCanvas';

interface QRFormProps {
  initialData?: any; // Nếu có data truyền vào thì là chế độ Sửa, không có là Tạo mới
  onSuccess: () => void;
  onCancel: () => void;
}

export default function QRForm({ initialData, onSuccess, onCancel }: QRFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Khởi tạo Form
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    defaultValues: {
      title: initialData?.title || '',
      destination_url: initialData?.destination_url || '',
      fgColor: initialData?.design_config?.fgColor || '#000000',
      logoImage: initialData?.design_config?.logoImage || '',
    }
  });

  // Theo dõi sự thay đổi của Form để vẽ lại QR
  const watchedValues = watch();
  // [CRITICAL LOGIC] Trì hoãn 300ms để không gọi hàm vẽ lại liên tục gây nóng máy
  const [debouncedValues] = useDebounce(watchedValues, 300);

  // [FILE UPLOAD] Xử lý chuyển đổi ảnh sang Base64 và Resize (< 100x100)
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 100;
        let width = img.width;
        let height = img.height;

        // Tính toán tỷ lệ thu nhỏ
        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Cập nhật Base64 vào Form
        setValue('logoImage', canvas.toDataURL('image/png'));
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Xử lý Gửi Form (Tạo mới hoặc Cập nhật)
  const onSubmit = async (data: any) => {
    setIsSubmitting(true);
    try {
      const payload = {
        title: data.title,
        destination_url: data.destination_url,
        design_config: {
          fgColor: data.fgColor,
          logoImage: data.logoImage,
        }
      };

      const url = initialData ? `/api/links/${initialData.id}` : '/api/links';
      const method = initialData ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Có lỗi xảy ra');
      }

      onSuccess(); // Gọi hàm reset danh sách ở file cha
    } catch (error: any) {
      alert(error.message); // Hiển thị Toast lỗi đơn giản (có thể nâng cấp thư viện Toast sau)
    } finally {
      setIsSubmitting(false);
    }
  };

  // Dummy URL để hiển thị bản xem trước khi đang tạo mới
  const previewUrl = debouncedValues.destination_url || 'https://dynamic-qr.com/preview';

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
      <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
        <h2 className="font-bold text-gray-900">
          {initialData ? 'Chỉnh sửa mã QR' : 'Tạo mã QR mới'}
        </h2>
        <button onClick={onCancel} className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">
          <X size={20} />
        </button>
      </div>

      {/* [UI RULES] Layout 2 cột trên Desktop, 1 cột trên Mobile */}
      <div className="flex flex-col-reverse md:flex-row p-6 gap-8">
        
        {/* Cột trái: Form nhập liệu */}
        <form onSubmit={handleSubmit(onSubmit)} className="flex-1 space-y-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Tên gợi nhớ</label>
            <input
              {...register('title', { required: 'Vui lòng nhập tên' })}
              placeholder="VD: Menu quán cafe tháng 4"
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors"
            />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title.message as string}</p>}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Đường link đích (URL)</label>
            <input
              {...register('destination_url', { 
                required: 'Vui lòng nhập URL',
                pattern: { value: /^https?:\/\/.+/, message: 'Link phải bắt đầu bằng http:// hoặc https://' }
              })}
              placeholder="https://your-website.com"
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors"
            />
            {errors.destination_url && <p className="text-red-500 text-xs mt-1">{errors.destination_url.message as string}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Màu sắc QR</label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  {...register('fgColor')}
                  className="w-10 h-10 p-1 border border-gray-200 rounded-lg cursor-pointer bg-white"
                />
                <span className="text-sm font-mono text-gray-500">{watchedValues.fgColor}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Logo ở giữa</label>
              <label className="flex items-center justify-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 hover:border-blue-500 hover:bg-blue-50 text-gray-600 rounded-xl cursor-pointer transition-colors">
                <ImageIcon size={18} />
                <span className="text-sm font-medium">Tải ảnh lên</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 flex justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 px-6 py-2.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors disabled:opacity-70"
            >
              {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
              {isSubmitting ? 'Đang lưu...' : 'Lưu mã QR'}
            </button>
          </div>
        </form>

        {/* Cột phải: Xem trước QR (Sticky) */}
        <div className="w-full md:w-[280px] shrink-0">
          <div className="sticky top-6 flex flex-col items-center">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Xem trước trực tiếp</p>
            {/* Sử dụng Component QRCanvas đã tạo ở Phase 2 */}
            <QRCanvas 
              value={previewUrl} 
              fgColor={debouncedValues.fgColor} 
              logoImage={debouncedValues.logoImage} 
            />
          </div>
        </div>

      </div>
    </div>
  );
}
