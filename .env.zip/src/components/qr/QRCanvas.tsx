"use client";

import React, { useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Download } from 'lucide-react'; // Icon tải xuống

interface QRCanvasProps {
  value: string;
  fgColor?: string;
  logoImage?: string;
}

export default function QRCanvas({ value, fgColor = '#000000', logoImage }: QRCanvasProps) {
  const qrRef = useRef<SVGSVGElement>(null);

  // [TÍNH NĂNG XUẤT FILE] Tải mã QR trực tiếp từ trình duyệt, không cần gọi Server
  const downloadQR = () => {
    if (!qrRef.current) return;
    
    const svg = qrRef.current;
    const svgData = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dynamic-qr.svg'; // Tên file khi tải về
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col items-center justify-center gap-4 p-6 bg-white rounded-2xl shadow-sm border border-gray-100">
      {/* Vẽ mã QR dưới dạng SVG để không bị vỡ hạt khi phóng to */}
      <QRCodeSVG
        ref={qrRef}
        value={value}
        size={220}
        fgColor={fgColor}
        level="H" // Mức độ sửa lỗi High (tốt nhất khi có logo chèn giữa)
        imageSettings={
          logoImage
            ? {
                src: logoImage,
                height: 48,
                width: 48,
                excavate: true, // Khoét nền QR để logo nổi bật
              }
            : undefined
        }
      />
      
      <button
        type="button"
        onClick={downloadQR}
        className="flex items-center gap-2 px-4 py-2 mt-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"
      >
        <Download size={16} />
        Tải xuống QR (SVG)
      </button>
    </div>
  );
}