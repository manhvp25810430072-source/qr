"use client";

import { useState, useEffect } from 'react';
import { X, Heart, Loader2, BarChart3 } from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';

interface AnalyticsModalProps {
  linkId: string;
  linkTitle: string;
  onClose: () => void;
}

const PIE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function AnalyticsModal({ linkId, linkTitle, onClose }: AnalyticsModalProps) {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await fetch(`/api/analytics/${linkId}`);
        if (!response.ok) throw new Error('Lỗi khi tải dữ liệu');
        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, [linkId]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Modal */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <BarChart3 className="text-blue-600" />
              Thống kê lượt quét
            </h2>
            <p className="text-sm text-gray-500 mt-1">Đang xem: <span className="font-semibold text-gray-700">{linkTitle}</span></p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Nội dung Modal */}
        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-64 gap-3 text-gray-500">
              <Loader2 size={32} className="animate-spin text-blue-600" />
              <p>Đang tải dữ liệu...</p>
            </div>
          ) : data?.clicks_by_date?.length === 0 ? (
            /* [XỬ LÝ LỖI DATA RỖNG] - Hiển thị Empty State theo chuẩn tài liệu */
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mb-6">
                <BarChart3 size={40} className="text-blue-300" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Mã QR này chưa có ai quét.</h3>
              <p className="text-gray-500 mb-8 max-w-md leading-relaxed">
                Hãy in và chia sẻ nó ngay nhé! Tôi xây dựng công cụ này để giúp bạn. Nếu gặp khó khăn hoặc muốn bình chọn cho dự án miễn phí tiếp theo, hãy tham gia cùng tôi ngay!
              </p>
              
              {/* [COMMUNITY BUTTON] Nút kêu gọi theo chuẩn UI/UX */}
              <a 
                href="https://www.facebook.com/share/1DAswa1imv/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gray-900 hover:bg-gray-800 text-white font-medium rounded-xl transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
              >
                <Heart size={18} className="text-pink-400" />
                Góp ý & Ủng hộ dự án tiếp theo
              </a>
            </div>
          ) : (
            /* Vẽ biểu đồ khi có dữ liệu */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Biểu đồ đường (Line Chart) - Lượt quét theo ngày */}
              <div className="lg:col-span-2 border border-gray-100 rounded-2xl p-4 shadow-sm">
                <h3 className="text-sm font-bold text-gray-700 mb-6 uppercase tracking-wider">Lượt quét 7 ngày qua</h3>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data?.clicks_by_date} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                      <XAxis 
                        dataKey="date" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#9ca3af', fontSize: 12 }}
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#9ca3af', fontSize: 12 }}
                      />
                      <RechartsTooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="count" 
                        stroke="#3b82f6" 
                        strokeWidth={3}
                        dot={{ r: 4, strokeWidth: 2, fill: '#fff' }} 
                        activeDot={{ r: 6, strokeWidth: 0, fill: '#3b82f6' }}
                        name="Lượt quét"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Biểu đồ tròn (Pie Chart) - Hệ điều hành */}
              <div className="border border-gray-100 rounded-2xl p-4 shadow-sm">
                <h3 className="text-sm font-bold text-gray-700 mb-6 uppercase tracking-wider">Hệ điều hành</h3>
                <div className="h-[300px] w-full flex flex-col justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={data?.clicks_by_os}
                        cx="50%"
                        cy="45%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="count"
                        nameKey="os"
                      >
                        {data?.clicks_by_os?.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <RechartsTooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Legend verticalAlign="bottom" height={36} iconType="circle" />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
}
