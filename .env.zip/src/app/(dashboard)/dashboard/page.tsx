"use client";

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Plus, Trash2, Edit3, BarChart2, Link as LinkIcon, ExternalLink, Download, Loader2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import QRForm from '@/components/qr/QRForm';
import AnalyticsModal from '@/components/ui/AnalyticsModal';

function DashboardContent() {
  const searchParams = useSearchParams();
  const createUrl = searchParams.get('createUrl');

  // --- STATE MANAGEMENT ---
  const [links, setLinks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // State điều khiển các Modal
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingLink, setEditingLink] = useState<any>(null);
  const [analyticsLink, setAnalyticsLink] = useState<any>(null);

  // Khởi tạo: Fetch dữ liệu và kiểm tra xem có cần mở Form tạo mới không
  useEffect(() => {
    fetchLinks();
    if (createUrl) {
      setEditingLink({ destination_url: createUrl });
      setIsFormOpen(true);
    }
  }, [createUrl]);

  // Hàm gọi API lấy danh sách
  const fetchLinks = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/links');
      if (!res.ok) throw new Error('Lỗi fetch data');
      const data = await res.json();
      setLinks(data);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  // Hàm Xóa link
  const handleDelete = async (id: string) => {
    if (!confirm('Bạn có chắc chắn muốn xóa mã QR này không? Hành động này không thể hoàn tác.')) return;
    
    try {
      const res = await fetch(`/api/links/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Xóa thất bại');
      // Cập nhật lại UI bằng cách lọc bỏ link đã xóa
      setLinks(links.filter(link => link.id !== id));
    } catch (error) {
      alert('Không thể xóa. Vui lòng thử lại.');
    }
  };

  // Hàm tải ảnh QR mini ngay từ Dashboard
  const downloadMiniQR = (shortId: string) => {
    const svg = document.getElementById(`qr-${shortId}`) as any;
    if (!svg) return;

    // [FIX LỖI QUÉT]: Nhân bản SVG để không làm ảnh hưởng giao diện web
    const clonedSvg = svg.cloneNode(true);
    // Ép kích thước file tải về lên 512x512 pixel để nét căng
    clonedSvg.setAttribute('width', '512');
    clonedSvg.setAttribute('height', '512');

    const svgData = new XMLSerializer().serializeToString(clonedSvg);
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `QR-${shortId}.svg`; // Giữ nguyên tên file đẹp
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Nếu đang mở Form tạo/sửa
  if (isFormOpen) {
    return (
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
        <QRForm 
          initialData={editingLink?.id ? editingLink : null} // Chỉ truyền ID nếu là Edit thực sự
          onSuccess={() => {
            setIsFormOpen(false);
            setEditingLink(null);
            fetchLinks(); // Load lại data mới
          }}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingLink(null);
          }}
        />
      </div>
    );
  }

  // --- GIAO DIỆN CHÍNH (DANH SÁCH QR) ---
  return (
    <div className="space-y-6">
      {/* Header Dashboard */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Quản lý mã QR</h1>
          <p className="text-gray-500 text-sm mt-1">Tạo, chỉnh sửa và theo dõi hiệu suất các đường link của bạn.</p>
        </div>
        <button
          onClick={() => setIsFormOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl transition-all shadow-sm w-full sm:w-auto justify-center"
        >
          <Plus size={18} />
          Tạo mã mới
        </button>
      </div>

      {/* Lưới danh sách QR */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Loader2 size={40} className="animate-spin mb-4 text-blue-500" />
          <p>Đang tải danh sách...</p>
        </div>
      ) : links.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center flex flex-col items-center">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            <LinkIcon size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Chưa có mã QR nào</h3>
          <p className="text-gray-500 mb-6">Bạn chưa tạo mã QR nào. Hãy bắt đầu bằng cách tạo một mã mới nhé!</p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="flex items-center gap-2 px-5 py-2 text-blue-600 bg-blue-50 hover:bg-blue-100 font-medium rounded-xl transition-all"
          >
            <Plus size={18} />
            Tạo mã đầu tiên
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {links.map((link) => {
            // Hiển thị domain động theo môi trường hiện tại
            const fullShortUrl = `${window.location.origin}/${link.short_id}`;
            
            return (
              <div key={link.id} className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 overflow-hidden flex flex-col">
                <div className="p-5 flex-1">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-bold text-gray-900 text-lg line-clamp-1 flex-1 pr-4">{link.title}</h3>
                    <span className="flex items-center gap-1.5 px-2.5 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-lg shrink-0">
                      <BarChart2 size={14} />
                      {link.total_clicks} lượt
                    </span>
                  </div>

                  <div className="flex gap-4 items-start">
                    {/* Hình ảnh QR Mini */}
                    <div className="bg-white p-2 rounded-xl border border-gray-100 shrink-0 shadow-sm relative group cursor-pointer" onClick={() => downloadMiniQR(link.short_id)}>
                      <QRCodeSVG
                        id={`qr-${link.short_id}`}
                        value={fullShortUrl}
                        size={80}
                        fgColor={link.design_config?.fgColor || '#000000'}
                        level="H"
                        imageSettings={link.design_config?.logoImage ? { src: link.design_config.logoImage, height: 20, width: 20, excavate: true } : undefined}
                      />
                      {/* Overlay tải xuống khi hover */}
                      <div className="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Download size={20} className="text-white" />
                      </div>
                    </div>

                    <div className="flex-1 min-w-0 flex flex-col justify-center space-y-2">
                      <div>
                        <p className="text-xs text-gray-500 font-medium mb-0.5">Link rút gọn</p>
                        <a href={fullShortUrl} target="_blank" rel="noreferrer" className="text-sm font-semibold text-blue-600 hover:underline flex items-center gap-1 truncate">
                          /{link.short_id} <ExternalLink size={12} className="shrink-0" />
                        </a>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 font-medium mb-0.5">Link đích</p>
                        <p className="text-sm text-gray-600 truncate" title={link.destination_url}>{link.destination_url}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Thanh công cụ Card */}
                <div className="grid grid-cols-3 border-t border-gray-50 bg-gray-50/50">
                  <button 
                    onClick={() => { setEditingLink(link); setIsFormOpen(true); }}
                    className="flex items-center justify-center gap-2 py-3 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-colors border-r border-gray-100"
                  >
                    <Edit3 size={16} /> Sửa
                  </button>
                  <button 
                    onClick={() => setAnalyticsLink(link)}
                    className="flex items-center justify-center gap-2 py-3 text-sm font-medium text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 transition-colors border-r border-gray-100"
                  >
                    <BarChart2 size={16} /> Thống kê
                  </button>
                  <button 
                    onClick={() => handleDelete(link.id)}
                    className="flex items-center justify-center gap-2 py-3 text-sm font-medium text-gray-600 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 size={16} /> Xóa
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Render Modal Thống kê */}
      {analyticsLink && (
        <AnalyticsModal 
          linkId={analyticsLink.id} 
          linkTitle={analyticsLink.title}
          onClose={() => setAnalyticsLink(null)} 
        />
      )}
    </div>
  );
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<div className="flex justify-center p-20"><Loader2 className="animate-spin text-blue-500" size={40} /></div>}>
      <DashboardContent />
    </Suspense>
  );
}
