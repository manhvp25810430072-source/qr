"use client";

import { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { LayoutDashboard, LogOut, LifeBuoy, QrCode } from 'lucide-react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // Xử lý đăng xuất
  const handleLogout = async () => {
    setIsLoggingOut(true);
    await supabase.auth.signOut();
    router.push('/login');
  };

  const navItems = [
    { name: 'Bảng điều khiển', href: '/dashboard', icon: LayoutDashboard },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* --- SIDEBAR (Cho Desktop) --- */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 fixed inset-y-0 z-10">
        <div className="p-6 flex items-center gap-2 font-bold text-xl tracking-tight text-gray-900 border-b border-gray-100">
          <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <QrCode size={18} />
          </div>
          DynamicQR.
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                  isActive 
                    ? 'bg-blue-50 text-blue-700' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon size={20} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-100 space-y-2">
          {/* [COMMUNITY BUTTON] Nút hỗ trợ cộng đồng */}
          <Link
            href="https://www.facebook.com/share/1DAswa1imv/"
            target="_blank"
            className="flex items-start gap-3 p-3 bg-indigo-50 hover:bg-indigo-100 rounded-xl text-indigo-700 transition-colors"
          >
            <LifeBuoy size={20} className="mt-0.5 shrink-0" />
            <span className="text-xs font-medium leading-relaxed">
              Bạn cần hỗ trợ kỹ thuật? Nhấn để thảo luận cùng tôi và cộng đồng.
            </span>
          </Link>

          <button
            onClick={handleLogout}
            disabled={isLoggingOut}
            className="flex items-center w-full gap-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl font-medium transition-all"
          >
            <LogOut size={20} />
            {isLoggingOut ? 'Đang thoát...' : 'Đăng xuất'}
          </button>
        </div>
      </aside>

      {/* --- MAIN CONTENT AREA --- */}
      <main className="flex-1 md:ml-64 pb-20 md:pb-0">
        {/* Header giả cho Mobile */}
        <header className="md:hidden flex items-center justify-between p-4 bg-white border-b border-gray-200 sticky top-0 z-10">
          <div className="flex items-center gap-2 font-bold text-lg text-gray-900">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <QrCode size={16} />
            </div>
            DynamicQR.
          </div>
          <button onClick={handleLogout} className="text-gray-500 hover:text-red-600 p-2">
            <LogOut size={20} />
          </button>
        </header>

        {/* Nội dung trang con sẽ được chèn vào đây */}
        <div className="p-4 md:p-8 max-w-6xl mx-auto">
          {children}
        </div>
      </main>

      {/* --- BOTTOM NAVIGATION (Cho Mobile) --- */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 z-20 flex items-center justify-around p-2 pb-safe">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex flex-col items-center gap-1 p-2 min-w-[64px] ${
                isActive ? 'text-blue-600' : 'text-gray-500'
              }`}
            >
              <Icon size={24} className={isActive ? 'fill-blue-50 text-blue-600' : ''} />
              <span className="text-[10px] font-medium">{item.name}</span>
            </Link>
          );
        })}
        
        {/* Nút hỗ trợ cộng đồng trên Mobile */}
        <Link
          href="https://www.facebook.com/share/1DAswa1imv/"
          target="_blank"
          className="flex flex-col items-center gap-1 p-2 min-w-[64px] text-indigo-500"
        >
          <LifeBuoy size={24} />
          <span className="text-[10px] font-medium">Hỗ trợ</span>
        </Link>
      </nav>
    </div>
  );
}


