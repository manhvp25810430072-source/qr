"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { QrCode, ArrowRight, Heart, Link2 } from 'lucide-react';
import Link from 'next/link';

export default function LandingPage() {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const handleCreateQR = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    setIsLoading(true);
    const supabase = createClient();
    
    // Kiểm tra xem user đã đăng nhập chưa
    const { data: { user } } = await supabase.auth.getUser();

    // [UI/UX DEAD-END] Bảo toàn trải nghiệm: Nếu chưa login, đẩy sang trang login kèm link vừa nhập
    if (!user) {
      router.push(`/login?redirectUrl=${encodeURIComponent(url)}`);
    } else {
      // Nếu đã login, đẩy thẳng vào Dashboard kèm dữ liệu để điền sẵn vào Form
      router.push(`/dashboard?createUrl=${encodeURIComponent(url)}`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-900 font-sans selection:bg-blue-100 selection:text-blue-900">
      
      {/* Header đơn giản */}
      <header className="p-6 flex items-center justify-between max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <QrCode size={18} />
          </div>
          DynamicQR.
        </div>
        <Link 
          href="/login"
          className="px-5 py-2.5 text-sm font-medium bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-all shadow-sm"
        >
          Đăng nhập
        </Link>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6 w-full max-w-3xl mx-auto text-center -mt-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 text-blue-600 text-xs font-semibold mb-6 border border-blue-100">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
          </span>
          Nền tảng tạo mã QR Động Miễn phí
        </div>
        
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-gray-900 mb-6 leading-tight">
          Rút gọn link & Tạo mã QR <br className="hidden sm:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
            trong tích tắc.
          </span>
        </h1>
        
        <p className="text-lg text-gray-500 mb-10 max-w-xl mx-auto">
          Cung cấp khả năng theo dõi lượt quét, thay đổi đường link đích bất cứ lúc nào mà không cần phải in lại mã QR của bạn.
        </p>

        <form onSubmit={handleCreateQR} className="w-full max-w-lg relative group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
            <Link2 className="h-5 w-5" />
          </div>
          <input
            type="url"
            required
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Nhập link cần tạo QR (vd: https://your-website.com)"
            className="block w-full pl-11 pr-32 py-4 sm:py-5 border-2 border-gray-200 rounded-2xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-0 focus:border-blue-500 transition-all shadow-sm bg-white text-base"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="absolute inset-y-2 right-2 flex items-center gap-2 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl transition-all disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Đang xử lý...' : 'Tạo ngay'}
            {!isLoading && <ArrowRight size={16} />}
          </button>
        </form>
      </main>

      {/* [VISION CALL-TO-ACTION] Footer */}
      <footer className="p-6 text-center mt-auto">
        <Link 
          href="https://www.facebook.com/share/1DAswa1imv/"
          target="_blank"
          className="inline-flex items-center gap-2 px-6 py-3 bg-gray-900 hover:bg-gray-800 text-white text-sm font-medium rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
        >
          <Heart size={16} className="text-pink-400" />
          Dự án này hoàn toàn miễn phí vì cộng đồng. Nhấn vào đây để nhận hỗ trợ 1-1 và cùng tôi quyết định dự án SaaS tiếp theo.
        </Link>
      </footer>
    </div>
  );
}
