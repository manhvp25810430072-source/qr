import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  // Nếu có param redirectUrl thì sau khi login xong sẽ trả về đó, mặc định là về Dashboard (ta sẽ setup ở Phase 4)
  const next = searchParams.get('redirectUrl') ?? '/';

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    
    if (!error) {
      // Xử lý chuyển hướng an toàn cho cả môi trường Local và Production
      const forwardedHost = request.headers.get('x-forwarded-host');
      const isLocalEnv = process.env.NODE_ENV === 'development';
      
      if (isLocalEnv) {
        return NextResponse.redirect(`${origin}${next}`);
      } else if (forwardedHost) {
        return NextResponse.redirect(`https://${forwardedHost}${next}`);
      } else {
        return NextResponse.redirect(`${origin}${next}`);
      }
    }
  }

  // Nếu có lỗi xảy ra, trả về trang chủ kèm thông báo lỗi
  return NextResponse.redirect(`${origin}/?error=auth-failed`);
}