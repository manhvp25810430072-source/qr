import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// --- API LẤY THỐNG KÊ (GET) ---
export async function GET(
  request: Request,
  { params }: { params: Promise<{ linkId: string }> }
) {
  try {
    const { linkId } = await params;
    const supabase = await createClient();
    
    // 1. Verify Session
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. [PERFORMANCE DIRECTIVE] BẮT BUỘC gọi RPC Function gom nhóm dữ liệu ngay tại DB
    const { data, error } = await supabase.rpc('get_link_analytics', {
      p_link_id: linkId
    });

    if (error) throw error;

    // Trả về dữ liệu đã được format sẵn: { clicks_by_date: [...], clicks_by_os: [...] }
    return NextResponse.json(data);
  } catch (error: any) {
    console.error('API Analytics GET Error:', error);
    return NextResponse.json({ error: 'Không thể tải dữ liệu thống kê' }, { status: 500 });
  }
}