import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// [CRITICAL DB DIRECTIVE] Khởi tạo Supabase bằng Service Role Key để có quyền ghi dữ liệu ẩn danh
// TUYỆT ĐỐI KHÔNG dùng Anon Key ở đây vì bảng scan_analytics không cho Public Insert
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// Khởi tạo một Map trên RAM server để làm Rate Limiting cơ bản (chống DDoS / spam click)
const rateLimitMap = new Map<string, { count: number; lastReset: number }>();

export async function POST(request: NextRequest) {
  try {
    // Lấy IP từ request để chặn spam
    const ip = request.headers.get('x-forwarded-for') || '127.0.0.1';
    
    // --- Cơ chế Rate Limiting (Tối đa 5 requests / 1 giây / 1 IP) ---
    const now = Date.now();
    const rateData = rateLimitMap.get(ip);
    
    if (rateData) {
      if (now - rateData.lastReset > 1000) {
        // Sau 1 giây, reset lại bộ đếm cho IP này
        rateLimitMap.set(ip, { count: 1, lastReset: now });
      } else {
        if (rateData.count >= 5) {
          return NextResponse.json({ error: 'Quá nhiều yêu cầu, vui lòng chậm lại' }, { status: 429 });
        }
        rateLimitMap.set(ip, { count: rateData.count + 1, lastReset: rateData.lastReset });
      }
    } else {
      rateLimitMap.set(ip, { count: 1, lastReset: now });
    }
    // -----------------------------------------------------------------

    // Parse dữ liệu từ Edge Route gửi sang
    const body = await request.json();
    const { link_id, os_name, device_type, country, referrer } = body;

    if (!link_id) {
      return NextResponse.json({ error: 'Thiếu link_id' }, { status: 400 });
    }

    // 1. Insert dữ liệu vào bảng scan_analytics
    const { error: insertError } = await supabaseAdmin
      .from('scan_analytics')
      .insert([
        { link_id, os_name, device_type, country, referrer }
      ]);

    if (insertError) throw insertError;

    // 2. [CRITICAL PERFORMANCE] Gọi RPC Function để tăng biến đếm total_clicks an toàn
    const { error: rpcError } = await supabaseAdmin.rpc('increment_clicks', {
      link_id_param: link_id
    });

    if (rpcError) throw rpcError;

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error('Tracking API Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}