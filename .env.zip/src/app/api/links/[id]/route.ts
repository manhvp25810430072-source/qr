import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// --- API CẬP NHẬT LINK (PATCH) ---
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> } // Chuẩn Next.js 15: params phải được await
) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    
    // 1. Verify Session lấy user_id
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Nhận dữ liệu update
    const body = await request.json();
    const { destination_url, title, design_config } = body;

    // [CRITICAL LOGIC - UPDATE DEAD-END] Tuyệt đối không cho update short_id
    // DB Query phải có điều kiện kép: id và user_id
    const { data, error } = await supabase
      .from('qr_links')
      .update({ destination_url, title, design_config, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(data);
  } catch (error: any) {
    console.error('API Links PATCH Error:', error);
    return NextResponse.json({ error: 'Không thể cập nhật link' }, { status: 500 });
  }
}

// --- API XÓA LINK (DELETE) ---
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const supabase = await createClient();
    
    // 1. Verify Session
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // [CRITICAL SECURITY] Xóa phải kèm user_id để chặn lỗ hổng IDOR
    const { error } = await supabase
      .from('qr_links')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('API Links DELETE Error:', error);
    return NextResponse.json({ error: 'Không thể xóa link' }, { status: 500 });
  }
}