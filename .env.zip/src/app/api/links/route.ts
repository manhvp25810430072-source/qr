import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { generateShortId } from '@/lib/utils';
import { z } from 'zod'; // Thư viện validate dữ liệu

// [DATA VALIDATION] Định nghĩa khung kiểm tra dữ liệu đầu vào
const linkSchema = z.object({
  destination_url: z.string().url('Đường dẫn không hợp lệ (phải bắt đầu bằng http/https)'),
  title: z.string().min(1, 'Vui lòng nhập tên gợi nhớ'),
  design_config: z.record(z.string(), z.any()).optional(),
});

// --- API LẤY DANH SÁCH LINK (GET) ---
export async function GET() {
  const supabase = await createClient();
  
  // 1. Verify Session lấy user_id
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // 2. Query lấy link của chính User đó (OrderBy mới nhất lên đầu)
  const { data, error } = await supabase
    .from('qr_links')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json(data);
}

// --- API TẠO MÃ QR MỚI (POST) ---
export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    
    // 1. Kiểm tra đăng nhập
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Nhận và Validate dữ liệu
    const body = await request.json();
    const validation = linkSchema.safeParse(body);
    
    if (!validation.success) {
      return NextResponse.json({ error: validation.error.issues[0].message }, { status: 400 });
    }

    const { destination_url, title, design_config } = validation.data;

    // 3. Khởi tạo mã ngắn (Short ID) đã làm ở Phase 2
    const short_id = generateShortId();

    // 4. Insert vào DB
    const { data, error } = await supabase
      .from('qr_links')
      .insert([
        {
          user_id: user.id,
          short_id,
          destination_url,
          title,
          design_config: design_config || {},
        }
      ])
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json(data, { status: 201 });
  } catch (error: any) {
    console.error('API Links POST Error:', error);
    return NextResponse.json({ error: 'Không thể tạo link, vui lòng thử lại' }, { status: 500 });
  }
}