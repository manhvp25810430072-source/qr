import { NextRequest, NextResponse } from 'next/server';
import { after } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// [CRITICAL PERFORMANCE] Chạy trên Edge Network để phản hồi siêu tốc độ
export const runtime = 'edge';

// Khởi tạo Supabase client trực tiếp vì Route này chạy trên Edge và policy "Public can read active links" đã được mở
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ shortId: string }> }
) {
  // Next.js 15 yêu cầu params phải được await
  const { shortId } = await params;

  // 1. Truy vấn DB lấy Link đích (Chỉ cần 1 truy vấn duy nhất)
  const { data: linkData, error } = await supabase
    .from('qr_links')
    .select('id, destination_url, is_active')
    .eq('short_id', shortId)
    .single();

  // 2. [XỬ LÝ LỖI 404] An toàn tuyệt đối, không văng lỗi 500 gây crash server
  if (error || !linkData || !linkData.is_active) {
    return new NextResponse(
      `<html>
        <head><meta charset="utf-8" /><title>Lỗi mã QR</title><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
        <body style="font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #f9fafb; color: #374151; text-align: center; padding: 20px;">
          <div>
            <h1 style="font-size: 24px; font-weight: 600; margin-bottom: 10px;">Mã QR không tồn tại hoặc đã bị khóa 🛑</h1>
            <p>Vui lòng kiểm tra lại đường dẫn hoặc liên hệ với người tạo mã.</p>
          </div>
        </body>
      </html>`,
      { status: 404, headers: { 'Content-Type': 'text/html' } }
    );
  }

  // 3. Trích xuất dữ liệu Tracking từ Request (IP, OS, Device)
  const userAgent = request.headers.get('user-agent') || '';
  const country = request.headers.get('x-vercel-ip-country') || 'Unknown';
  const referrer = request.headers.get('referer') || 'Direct';

  // Parse hệ điều hành (OS) cơ bản
  let os_name = 'Unknown';
  if (userAgent.includes('Win')) os_name = 'Windows';
  else if (userAgent.includes('Mac') || userAgent.includes('iPhone') || userAgent.includes('iPad')) os_name = userAgent.includes('Mac') ? 'macOS' : 'iOS';
  else if (userAgent.includes('Android')) os_name = 'Android';
  else if (userAgent.includes('Linux')) os_name = 'Linux';

  // Parse loại thiết bị cơ bản
  let device_type = 'Desktop';
  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(userAgent)) {
    device_type = 'Mobile';
  } else if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(userAgent)) {
    device_type = 'Tablet';
  }

  const trackingPayload = {
    link_id: linkData.id,
    os_name,
    device_type,
    country,
    referrer,
  };

  // 4. [CRITICAL PERFORMANCE - FIRE AND FORGET] 
  // Hàm after() bọc tác vụ Tracking lại, Edge sẽ không đợi fetch xong mới trả về cho User
  after(() => {
    // [CRITICAL BUG PREVENTION] Truyền Absolute URL
    fetch(new URL('/api/track', request.url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(trackingPayload),
    }).catch(err => console.error('Tracking Error:', err));
  });

  // 5. Trả về Redirect (HTTP 302) để trình duyệt không lưu Cache vĩnh viễn
  return NextResponse.redirect(linkData.destination_url, 302);
}
