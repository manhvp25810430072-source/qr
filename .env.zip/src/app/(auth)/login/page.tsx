"use client";

import { Suspense } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useSearchParams } from 'next/navigation';
import { ArrowLeft, QrCode } from 'lucide-react';
import Link from 'next/link';

// Component nhỏ xử lý logic form đăng nhập
function LoginForm() {
  const searchParams = useSearchParams();
  const redirectUrl = searchParams.get('redirectUrl') || '/dashboard';

  const handleGoogleLogin = async () => {
    const supabase = createClient();
    const origin = window.location.origin;
    
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${origin}/api/auth/callback?redirectUrl=${encodeURIComponent(redirectUrl)}`,
      },
    });
  };

  return (
    <div className="w-full max-w-md p-8 sm:p-10 bg-white rounded-3xl shadow-sm border border-gray-100 text-center">
      <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
        <QrCode size={28} />
      </div>
      <h1 className="text-2xl font-extrabold text-gray-900 mb-2">Chào mừng trở lại</h1>
      <p className="text-gray-500 mb-8 text-sm">Đăng nhập để tạo và quản lý mã QR động của riêng bạn.</p>

      <button
        onClick={handleGoogleLogin}
        className="w-full flex items-center justify-center gap-3 px-4 py-3.5 bg-white border-2 border-gray-200 hover:bg-gray-50 hover:border-gray-300 text-gray-700 font-semibold rounded-xl transition-all"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
        Tiếp tục với Google
      </button>
    </div>
  );
}

// BẮT BUỘC PHẢI CÓ DÒNG NÀY (export default function)
export default function LoginPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4 relative selection:bg-blue-100 selection:text-blue-900">
      <div className="absolute top-6 left-6">
        <Link 
          href="/"
          className="flex items-center gap-2 p-2.5 text-gray-500 hover:text-gray-900 bg-white rounded-xl shadow-sm border border-gray-200 hover:border-gray-300 transition-all"
        >
          <ArrowLeft size={18} />
          <span className="text-sm font-medium pr-2 hidden sm:block">Trang chủ</span>
        </Link>
      </div>

      <Suspense fallback={<div className="animate-pulse w-full max-w-md h-72 bg-gray-200 rounded-3xl"></div>}>
        <LoginForm />
      </Suspense>
    </div>
  );
}
