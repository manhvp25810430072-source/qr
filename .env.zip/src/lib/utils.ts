import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { customAlphabet } from 'nanoid';

// Hàm hỗ trợ gộp class cho Tailwind CSS (sẽ dùng nhiều ở Phase 4)
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// [CRITICAL LOGIC] Thuật toán tạo Short ID (URL-safe, độ dài mặc định 6 ký tự)
// Chỉ sử dụng chữ cái và số để mã QR quét không bị lỗi ký tự lạ
export const generateShortId = customAlphabet(
  '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
  6
);