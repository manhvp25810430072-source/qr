import { createBrowserClient } from '@supabase/ssr'

export function createClient() {
  // createBrowserClient tự động áp dụng Singleton pattern phía dưới engine
  // giúp tránh khởi tạo lại nhiều lần gây re-render UI
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}