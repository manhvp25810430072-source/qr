import { NextResponse, type NextRequest } from 'next/server';
import { createServerClient } from '@supabase/ssr';

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  // Khởi tạo Supabase Client để check Cookie/Session
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          supabaseResponse = NextResponse.next({
            request,
          });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // Gọi getUser để Supabase tự động refresh token nếu hết hạn
  const { data: { user } } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;

  // [CRITICAL SECURITY] Bảo vệ trang Dashboard
  // Nếu vào trang /dashboard mà chưa có session (chưa đăng nhập) -> Bắn về /login
  if (path.startsWith('/dashboard') && !user) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }

  // Tiện ích UI/UX: Nếu đã đăng nhập rồi mà lỡ bấm vào trang /login -> Đẩy thẳng vào Dashboard luôn
  if (path.startsWith('/login') && user) {
    const url = request.nextUrl.clone();
    url.pathname = '/dashboard';
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}

// [PERFORMANCE DIRECTIVE] 
// Cấu hình matcher để Middleware bỏ qua các file tĩnh (ảnh, css) và API tracking (/api/track)
// Đảm bảo tốc độ quét QR ở Edge Network không bị ảnh hưởng.
export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|api/track|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};