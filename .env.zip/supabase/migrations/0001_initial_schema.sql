-- 1. Bảng Hồ Sơ Người Dùng (Liên kết tự động với auth.users của Supabase)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    full_name TEXT,
    avatar_url TEXT,
    plan_type TEXT DEFAULT 'FREE' CHECK (plan_type IN ('FREE', 'PRO')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Bật Row Level Security (RLS) bảo vệ dữ liệu cá nhân
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- 2. Bảng Link QR Động (Lưu trữ URL đích và ID mã ngắn)
CREATE TABLE IF NOT EXISTS public.qr_links (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    short_id TEXT UNIQUE NOT NULL, -- Mã ngắn gắn trên QR. VD: 'aB3x9Y'
    destination_url TEXT NOT NULL, -- Link đích người dùng muốn chuyển tới
    title TEXT, -- Tên gợi nhớ (VD: 'Menu Quán Tháng 4')
    design_config JSONB DEFAULT '{}'::jsonb, -- Lưu cấu hình màu sắc, logo của mã QR
    total_clicks INTEGER DEFAULT 0, -- Bộ đếm nhanh (Cache) để giảm tải truy vấn
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- [CRITICAL PERFORMANCE] Tạo Index để tốc độ tìm kiếm Link đích khi quét mã chỉ mất <10ms
CREATE INDEX IF NOT EXISTS idx_qr_links_short_id ON public.qr_links(short_id);
CREATE INDEX IF NOT EXISTS idx_qr_links_user_id ON public.qr_links(user_id);

ALTER TABLE public.qr_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own links" ON public.qr_links FOR ALL USING (auth.uid() = user_id);
-- [CRITICAL SECURITY EXCEPTION]: BẮT BUỘC cho phép Public đọc (Select) các link đang Active để Serverless Function có thể truy xuất và chuyển hướng khách vãng lai khi họ quét mã.
CREATE POLICY "Public can read active links" ON public.qr_links FOR SELECT USING (is_active = true);

-- 3. Bảng Dữ Liệu Quét (Tracking Analytics)
CREATE TABLE IF NOT EXISTS public.scan_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    link_id UUID REFERENCES public.qr_links(id) ON DELETE CASCADE NOT NULL,
    scanned_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    os_name TEXT,       -- Hệ điều hành (iOS, Android, Windows)
    device_type TEXT,   -- Thiết bị (Mobile, Tablet, Desktop)
    country TEXT,       -- Quốc gia (Parse từ IP)
    referrer TEXT       -- Nguồn truy cập
);

-- [CRITICAL PERFORMANCE] Tạo Index để vẽ biểu đồ thống kê trên Dashboard không bị treo
CREATE INDEX IF NOT EXISTS idx_scan_analytics_link_id ON public.scan_analytics(link_id);
CREATE INDEX IF NOT EXISTS idx_scan_analytics_time ON public.scan_analytics(scanned_at DESC);

ALTER TABLE public.scan_analytics ENABLE ROW LEVEL SECURITY;
-- Người dùng chỉ được xem thống kê của các link do chính họ tạo ra
CREATE POLICY "Users can view own analytics" ON public.scan_analytics FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.qr_links WHERE public.qr_links.id = link_id AND public.qr_links.user_id = auth.uid())
);
-- Hệ thống tự động Insert dữ liệu tracking ẩn danh từ phía Backend/Edge.
-- KHÔNG cấp quyền Insert cho Public User.

-- 4. [CRITICAL PERFORMANCE] RPC Function: Atomic Increment cho total_clicks
-- API ở Edge Network sẽ gọi hàm này để tăng biến đếm mà không bị dính lỗi Race Condition.
CREATE OR REPLACE FUNCTION increment_clicks(link_id_param UUID)
RETURNS void AS $$
BEGIN
  UPDATE public.qr_links
  SET total_clicks = total_clicks + 1
  WHERE id = link_id_param;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. [CRITICAL SYSTEM DIRECTIVE] Trigger: Tự động tạo Profile khi User đăng ký
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 6. [CRITICAL PERFORMANCE] RPC Function: Get Analytics Aggregation
-- Hỗ trợ API /api/analytics/[linkId] gom nhóm dữ liệu ngay tại DB để chống tràn RAM trình duyệt
CREATE OR REPLACE FUNCTION get_link_analytics(p_link_id UUID)
RETURNS json AS $$
DECLARE
  v_clicks_by_date json;
  v_clicks_by_os json;
BEGIN
  SELECT COALESCE(json_agg(row_to_json(t)), '[]'::json) INTO v_clicks_by_date
  FROM (
    SELECT to_char(scanned_at, 'YYYY-MM-DD') AS date, count(*)::int AS count
    FROM public.scan_analytics
    WHERE link_id = p_link_id
    GROUP BY to_char(scanned_at, 'YYYY-MM-DD')
    ORDER BY date
  ) t;

  SELECT COALESCE(json_agg(row_to_json(t)), '[]'::json) INTO v_clicks_by_os
  FROM (
    SELECT os_name AS os, count(*)::int AS count
    FROM public.scan_analytics
    WHERE link_id = p_link_id
    GROUP BY os_name
  ) t;

  RETURN json_build_object(
    'clicks_by_date', v_clicks_by_date,
    'clicks_by_os', v_clicks_by_os
  );
END;
$$ LANGUAGE plpgsql SECURITY INVOKER;

-- 7. [CRITICAL MAINTENANCE] Cron Job: Tự động xóa log cũ > 90 ngày để bảo vệ dung lượng 500MB (Free Tier)
-- Yêu cầu: Bật extension "pg_cron" trong Dashboard Supabase trước.
SELECT cron.schedule('delete-old-logs', '0 0 * * *', $$
  DELETE FROM public.scan_analytics
  WHERE scanned_at < now() - interval '90 days';
$$);
